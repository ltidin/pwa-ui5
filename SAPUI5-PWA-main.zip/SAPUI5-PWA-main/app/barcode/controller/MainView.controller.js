sap.ui.define([
	"sap/ui/core/mvc/Controller",
    "sap/m/MessageBox"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function(Controller, MessageBox) {
		"use strict";

		return Controller.extend("pocui5.barcode.controller.MainView", {
			onInit: function () {},

			onSuccess: function(oEvent) {
                const sScanResult = oEvent.getParameter("text");
                MessageBox.show(`Scanned code: ${sScanResult}`);

                this.byId("scanResultTxt").setText(sScanResult);
			},

			onError: function(oError) {
				MessageBox.error("Scan failed");
                console.log(oError);
			},
            onPress: function(){
                alert("test");
            }
		});
	});
